# Noqta Production Deployment

## PostgreSQL
1. Create a PostgreSQL database.
2. Run `schema.sql` against it.
3. Set `DATABASE_URL` and a strong `NOQTA_SECRET`.
4. Set `ADMIN_EMAILS` to the email(s) that may administer moderation.
5. Install dependencies with `npm ci` and start with `npm start`.

When `DATABASE_URL` exists, Noqta automatically uses PostgreSQL. Without it, the local JSON database remains available for development.

## Docker
Build and run with a PostgreSQL connection string injected as an environment variable. Do not put secrets in the image or repository.

## Before public launch
- Put the API behind HTTPS.
- Use a managed PostgreSQL database with backups.
- Configure a real email provider for verification/password recovery.
- Replace demo/admin defaults with explicit production accounts.
- Add rate limiting/WAF at the hosting layer.
- Set a production domain and privacy-policy URL.
- Run iOS/Android release builds and store review checks.
