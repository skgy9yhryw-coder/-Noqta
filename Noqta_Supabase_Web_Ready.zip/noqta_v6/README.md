# Noqta v0.6 — Full-stack connected build

## What is included
- Same-origin web app + real Node backend.
- Persistent JSON database for the current MVP (easy migration to PostgreSQL/Supabase later).
- Register/login with scrypt password hashing and session tokens.
- Events, saved events, reports, moderation, account deletion.
- Admin role for `@noqta.demo` accounts in this development build.
- Security headers and no attendee/presence model.

## Run
Requires Node 20+.

```bash
NOQTA_SECRET="use-a-long-random-secret" npm start
```
Then open `http://localhost:3000`.

## Important before public production
Replace the JSON database with managed PostgreSQL/Supabase, move sessions to a secure persistent store, configure HTTPS/domain, email verification/password recovery, backups, rate limiting/WAF, monitoring, and real App Store/Google Play signing credentials.
