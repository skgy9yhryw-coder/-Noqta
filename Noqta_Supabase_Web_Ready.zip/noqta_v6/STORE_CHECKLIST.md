# Noqta store-readiness checklist

## Completed in this package
- Mobile-first responsive UI
- PWA manifest and service worker
- iOS/Android Capacitor wrapper configuration
- Stable application ID: com.noqta.app
- Store icon assets: 1024/512/192
- Privacy-by-design product rule: no attendee identity/presence list
- Terms and privacy drafts
- Account deletion requirement documented

## Still required before public store release
- Production cloud backend and PostgreSQL database
- Real authentication and secure session/token handling
- Production API URL and HTTPS
- Backend account deletion endpoint
- Server-side authorization for admin moderation
- Abuse/rate-limit protection and logging
- Final privacy policy/legal entity/contact details
- Apple Developer account + signing + App Store metadata/review
- Google Play Console account + signing + Play metadata/review
- Real device testing on supported iOS/Android versions
- Final screenshots, app description, age/content rating and data-safety declarations
