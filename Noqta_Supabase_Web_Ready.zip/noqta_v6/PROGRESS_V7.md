# Noqta v7 progress

Completed in this iteration:
- PostgreSQL production schema for users, events, saved events, reports, and sessions.
- PostgreSQL backend mode with the same frontend API contract.
- Automatic database selection: PostgreSQL when `DATABASE_URL` is present, local JSON otherwise.
- Persistent sessions with 30-day expiry in PostgreSQL.
- Admin moderation controlled by `ADMIN_EMAILS` rather than a hard-coded demo domain.
- Dockerfile and deployment instructions.
- Local fallback preserved for development/testing.

Still requires external credentials/hosting:
- Provision the managed PostgreSQL instance.
- Configure production secrets.
- Configure domain/HTTPS and email provider.
- Apple/Google signing accounts and store submission.
