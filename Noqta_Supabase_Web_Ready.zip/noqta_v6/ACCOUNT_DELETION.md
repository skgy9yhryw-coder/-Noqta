# Account deletion requirement

Before store submission, Noqta must expose an in-app account deletion path and a corresponding backend endpoint that permanently deletes or anonymizes account-associated data according to the final retention policy.

Planned endpoint: DELETE /me

This is a release blocker until implemented against the production backend.
