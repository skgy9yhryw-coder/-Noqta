# Noqta Privacy Policy — Draft for store submission

Noqta is designed around privacy by design. The app focuses on places, events and aggregate vibe information and does not expose attendee identities or a list of people at a location.

## Data we use
- Account information needed for sign-in and account management.
- Event information submitted by users, including title, category, place and event timing.
- Saved events and reports associated with the signed-in account.
- Device location only when the user grants permission, to calculate nearby event relevance.

## What we do not expose
- No attendee list.
- No attendee IDs in public event responses.
- No public "people at this location" list.

## Control
Users can request account deletion and removal of account-associated data through the account settings/support process.

This document is a submission draft and must be reviewed and updated with the final legal entity, contact email, retention periods, processors and hosting providers before production release.
