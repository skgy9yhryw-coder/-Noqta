# Noqta Terms of Service — Draft

Noqta helps users discover local events and atmospheres. Users must provide accurate event information and must not submit illegal, harmful, deceptive, discriminatory or abusive content.

Noqta may moderate, approve, reject or remove submitted events and reports. Users may report content they believe violates these terms.

The final production terms must include the legal operator, jurisdiction, support contact, refund rules where applicable, and other terms required for the launch market.
