# Noqta — Supabase web deployment

The current `www/index.html` is a static web app and talks directly to Supabase using the project's publishable key. It does not depend on the old Node API for normal production use.

Recommended hosting: GitHub Pages / Netlify / Vercel. The site must be HTTPS for reliable geolocation, PWA behavior and production auth redirects.

After the site has a final HTTPS URL, set it in Supabase Authentication → URL Configuration as the Site URL and add the same URL to Redirect URLs if required by your auth flow.

Before store submission:
- Deploy `supabase/functions/delete-account`.
- Verify Email Auth settings and production redirect URL.
- Create the first admin by updating that user's `profiles.role` in SQL after signup.
- Run the optional seed only for a demo environment.
