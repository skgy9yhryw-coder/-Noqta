CREATE TABLE IF NOT EXISTS users (
 id BIGSERIAL PRIMARY KEY,
 email TEXT UNIQUE NOT NULL,
 display_name TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
 password_hash TEXT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS events (
 id BIGSERIAL PRIMARY KEY,
 name TEXT NOT NULL,
 category TEXT NOT NULL,
 place TEXT NOT NULL,
 time TEXT NOT NULL,
 price TEXT NOT NULL,
 icon TEXT NOT NULL,
 lat DOUBLE PRECISION NOT NULL,
 lon DOUBLE PRECISION NOT NULL,
 vibe TEXT NOT NULL,
 time_state TEXT NOT NULL,
 description TEXT NOT NULL DEFAULT '',
 tags JSONB NOT NULL DEFAULT '[]'::jsonb,
 status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
 created_by BIGINT REFERENCES users(id) ON DELETE SET NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 moderated_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS saved_events (
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 event_id BIGINT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 PRIMARY KEY(user_id,event_id)
);
CREATE TABLE IF NOT EXISTS reports (
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 event_id BIGINT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
 reason TEXT NOT NULL DEFAULT 'other',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS sessions (
 token TEXT PRIMARY KEY,
 user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 expires_at TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS events_status_idx ON events(status);
CREATE INDEX IF NOT EXISTS events_category_idx ON events(category);
CREATE INDEX IF NOT EXISTS reports_event_idx ON reports(event_id);
