if(process.env.DATABASE_URL){require('./server-pg')}else{require('./server')}
