# Noqta Supabase deployment

The web client uses Supabase Auth + Postgres directly. The publishable key is safe to ship in the browser; database security comes from RLS. Never put a service-role key in `www/`.

## One-time optional demo data
Run `SEED_EVENTS.sql` in Supabase SQL Editor.

## Account deletion
Deploy `functions/delete-account/index.ts` as the `delete-account` Edge Function. The platform injects `SUPABASE_URL`, `SUPABASE_ANON_KEY`, and `SUPABASE_SERVICE_ROLE_KEY`; the service-role key stays server-side.
