-- Optional demo content for Noqta. Run once in Supabase SQL Editor.
insert into public.events
  (title, category, place, lat, lon, starts_at, ends_at, price_text, vibe, description, status)
select * from (values
  ('Live Music', 'music', 'Rotterdam Centrum', 51.916, 4.479,
   now() - interval '20 minutes', now() + interval '80 minutes', 'مجاني', 'high', 'موسيقى وأجواء اجتماعية الليلة.', 'approved'),
  ('Street Event', 'party', 'Witte de Withstraat', 51.914, 4.475,
   now() + interval '20 minutes', now() + interval '140 minutes', '€10', 'high', 'فعالية ليلية في وسط المدينة.', 'approved'),
  ('Food Event', 'food', 'Markthal', 51.920, 4.486,
   now() + interval '2 hours', now() + interval '5 hours', '€5', 'medium', 'تجربة أكل متنوعة.', 'approved'),
  ('Evening Tour', 'tourism', 'Erasmusbrug', 51.910, 4.487,
   now() + interval '3 hours', now() + interval '5 hours', '€15', 'low', 'جولة مسائية جميلة.', 'approved')
) as seed(title, category, place, lat, lon, starts_at, ends_at, price_text, vibe, description, status)
where not exists (select 1 from public.events e where e.title = seed.title and e.place = seed.place);
